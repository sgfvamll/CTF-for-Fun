//===- LoopDeletion.cpp - Dead Loop Deletion Pass ---------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//
//
// This file implements the Dead Loop Deletion Pass. This pass is responsible
// for eliminating loops with non-infinite computable trip counts that have no
// side effects or volatile instructions, and do not contribute to the
// computation of the function's return value.
//
//===----------------------------------------------------------------------===//

#include "Opt.h"
#include "llvm/ADT/SmallVector.h"
#include "llvm/ADT/Statistic.h"
#include "llvm/Analysis/CFG.h"
#include "llvm/Analysis/GlobalsModRef.h"
#include "llvm/Analysis/InstructionSimplify.h"
#include "llvm/Analysis/LoopIterator.h"
#include "llvm/Analysis/LoopPass.h"
#include "llvm/Analysis/MemorySSA.h"
#include "llvm/Analysis/OptimizationRemarkEmitter.h"
#include "llvm/IR/Dominators.h"
#include "llvm/Transforms/Utils/BasicBlockUtils.h"
#include "llvm/Transforms/Utils/Local.h"
#include "llvm/Analysis/MemorySSAUpdater.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/PatternMatch.h"
#include "llvm/InitializePasses.h"
#include "llvm/Transforms/Scalar.h"
#include "llvm/Transforms/Scalar/LoopPassManager.h"
#include "llvm/Transforms/Utils/LoopUtils.h"
#include "llvm/Passes/PassBuilder.h"
#include "llvm/Passes/PassPlugin.h"

using namespace llvm;

#define DEBUG_TYPE "loop-delete"

static constexpr char PassArg[] = "myloop-deletion";
static constexpr char PluginName[] = "MyLoopDeletion";

enum class LoopDeletionResult
{
  Unmodified,
  Modified,
  Deleted,
};

static Value *
getValueOnFirstIteration(Value *V, DenseMap<Value *, Value *> &FirstIterValue,
                         const SimplifyQuery &SQ)
{
  // Quick hack: do not flood cache with non-instruction values.
  if (!isa<Instruction>(V))
    return V;
  // Do we already know cached result?
  auto Existing = FirstIterValue.find(V);
  if (Existing != FirstIterValue.end())
    return Existing->second;
  Value *FirstIterV = nullptr;
  if (auto *CAST = dyn_cast<SExtInst>(V))
  {
    Value *OP0 =
        getValueOnFirstIteration(CAST->getOperand(0), FirstIterValue, SQ);
    FirstIterV = SimplifyCastInst(CAST->getOpcode(), OP0, CAST->getDestTy(), SQ);
  }
  if (auto *BO = dyn_cast<BinaryOperator>(V))
  {
    Value *LHS =
        getValueOnFirstIteration(BO->getOperand(0), FirstIterValue, SQ);
    Value *RHS =
        getValueOnFirstIteration(BO->getOperand(1), FirstIterValue, SQ);
    FirstIterV = SimplifyBinOp(BO->getOpcode(), LHS, RHS, SQ);
  }
  if (!FirstIterV)
  {
    FirstIterV = V;
  }
  FirstIterValue[V] = FirstIterV;
  return FirstIterV;
}

// Try to prove that one of conditions that dominates the latch must exit on 1st
// iteration.
static int numIteration(Loop *L, DominatorTree &DT,
                        LoopInfo &LI)
{
  BasicBlock *Predecessor = L->getLoopPredecessor();
  BasicBlock *Latch = L->getLoopLatch();

  SmallVector<BasicBlock *, 4> ExitBlocks;
  L->getExitBlocks(ExitBlocks);

  if (!Predecessor || !Latch)
    return -1;

  LoopBlocksRPO RPOT(L);
  RPOT.perform(&LI);

  // For the optimization to be correct, we need RPOT to have a property that
  // each block is processed after all its predecessors, which may only be
  // violated for headers of the current loop and all nested loops. Irreducible
  // CFG provides multiple ways to break this assumption, so we do not want to
  // deal with it.
  if (containsIrreducibleCFG<const BasicBlock *>(RPOT, LI))
    return -1;

  BasicBlock *Header = L->getHeader();
  // Blocks that are reachable on the 1st iteration.
  SmallPtrSet<BasicBlock *, 4> LiveBlocks;
  // Edges that are reachable on the 1st iteration.
  DenseSet<BasicBlockEdge> LiveEdges;
  LiveBlocks.insert(Header);

  SmallPtrSet<BasicBlock *, 4> Visited;
  auto MarkLiveEdge = [&](BasicBlock *From, BasicBlock *To)
  {
    assert(LiveBlocks.count(From) && "Must be live!");
    assert((LI.isLoopHeader(To) || !Visited.count(To)) &&
           "Only canonical backedges are allowed. Irreducible CFG?");
    assert((LiveBlocks.count(To) || !Visited.count(To)) &&
           "We already discarded this block as dead!");
    LiveBlocks.insert(To);
    LiveEdges.insert({From, To});
  };

  auto MarkAllSuccessorsLive = [&](BasicBlock *BB)
  {
    for (auto *Succ : successors(BB))
      MarkLiveEdge(BB, Succ);
  };

  // Check if there is only one value coming from all live predecessor blocks.
  // Note that because we iterate in RPOT, we have already visited all its
  // (non-latch) predecessors.
  auto GetSoleInputOnFirstIteration = [&](PHINode &PN) -> Value *
  {
    BasicBlock *BB = PN.getParent();
    bool HasLivePreds = false;
    (void)HasLivePreds;
    if (BB == Header)
    {
      return PN.getIncomingValueForBlock(Predecessor);
    }
    Value *OnlyInput = nullptr;
    for (auto *Pred : predecessors(BB))
      if (LiveEdges.count({Pred, BB}))
      {
        HasLivePreds = true;
        Value *Incoming = PN.getIncomingValueForBlock(Pred);
        // Skip undefs. If they are present, we can assume they are equal to
        // the non-undef input.
        if (isa<UndefValue>(Incoming))
          continue;
        // Two inputs.
        if (OnlyInput && OnlyInput != Incoming)
          return nullptr;
        OnlyInput = Incoming;
      }

    assert(HasLivePreds && "No live predecessors?");
    // If all incoming live value were undefs, return undef.
    return OnlyInput ? OnlyInput : UndefValue::get(PN.getType());
  };
  DenseMap<Value *, Value *> FirstIterValue;

  // Use the following algorithm to prove we never take the latch on the 1st
  // iteration:
  // 1. Traverse in topological order, so that whenever we visit a block, all
  //    its predecessors are already visited.
  // 2. If we can prove that the block may have only 1 predecessor on the 1st
  //    iteration, map all its phis onto input from this predecessor.
  // 3a. If we can prove which successor of out block is taken on the 1st
  //     iteration, mark this successor live.
  // 3b. If we cannot prove it, conservatively assume that all successors are
  //     live.
  auto &DL = Header->getModule()->getDataLayout();
  const SimplifyQuery SQ(DL);
  for (auto *BB : RPOT)
  {
    Visited.insert(BB);

    // This block is not reachable on the 1st iterations.
    if (!LiveBlocks.count(BB))
      continue;

    // Skip inner loops.
    if (LI.getLoopFor(BB) != L)
    {
      MarkAllSuccessorsLive(BB);
      continue;
    }

    // If Phi has only one input from all live input blocks, use it.
    for (auto &PN : BB->phis())
    {
      if (!PN.getType()->isIntegerTy())
        continue;
      auto *Incoming = GetSoleInputOnFirstIteration(PN);
      if (Incoming && DT.dominates(Incoming, BB->getTerminator()))
      {
        Value *FirstIterV =
            getValueOnFirstIteration(Incoming, FirstIterValue, SQ);
        FirstIterValue[&PN] = FirstIterV;
      }
    }

    using namespace PatternMatch;
    ICmpInst::Predicate Pred;
    Value *LHS, *RHS;
    BasicBlock *IfTrue, *IfFalse;
    auto *Term = BB->getTerminator();
    if (match(Term, m_Br(m_ICmp(Pred, m_Value(LHS), m_Value(RHS)),
                         m_BasicBlock(IfTrue), m_BasicBlock(IfFalse))))
    {
      if (!LHS->getType()->isIntegerTy())
      {
        MarkAllSuccessorsLive(BB);
        continue;
      }

      // Can we prove constant true or false for this condition?
      LHS = getValueOnFirstIteration(LHS, FirstIterValue, SQ);
      RHS = getValueOnFirstIteration(RHS, FirstIterValue, SQ);
      auto *KnownCondition = SimplifyICmpInst(Pred, LHS, RHS, SQ);
      if (!KnownCondition)
      {
        // Failed to simplify.
        MarkAllSuccessorsLive(BB);
        continue;
      }
      assert(!isa<UndefValue>(KnownCondition) && "Branching on UndefValue is undefined. ");
      auto *ConstCondition = dyn_cast<ConstantInt>(KnownCondition);
      if (!ConstCondition)
      {
        // Non-constant condition, cannot analyze any further.
        MarkAllSuccessorsLive(BB);
        continue;
      }
      if (ConstCondition->isAllOnesValue())
        MarkLiveEdge(BB, IfTrue);
      else
        MarkLiveEdge(BB, IfFalse);
    }
    else if (SwitchInst *SI = dyn_cast<SwitchInst>(Term))
    {
      auto *SwitchValue = SI->getCondition();
      auto *SwitchValueOnFirstIter =
          getValueOnFirstIteration(SwitchValue, FirstIterValue, SQ);
      auto *ConstSwitchValue = dyn_cast<ConstantInt>(SwitchValueOnFirstIter);
      if (!ConstSwitchValue)
      {
        MarkAllSuccessorsLive(BB);
        continue;
      }
      auto CaseIterator = SI->findCaseValue(ConstSwitchValue);
      MarkLiveEdge(BB, CaseIterator->getCaseSuccessor());
    }
    else
    {
      MarkAllSuccessorsLive(BB);
      continue;
    }
  }

  for (int i = 0; i < ExitBlocks.size(); i++)
  {
    // Error 1: Possible edge Header->ExitBlock is turned into Must Taken Edge
    if (LiveEdges.count({Header, ExitBlocks[i]}))
      return 0;
  }

  for (int i = 0; i < ExitBlocks.size(); i++)
    // Error 2: Possible edge SomeBlock->ExitBlock is turned into Must Taken Edge
    for (auto edge : LiveEdges)
      if (edge.getEnd() == ExitBlocks[i])
        return 1;

  if (!LiveEdges.count({Latch, Header}))
    // We can break the latch if it wasn't live.
    return 1;

  using namespace PatternMatch;
  ICmpInst::Predicate Pred;
  Value *LHS, *RHS;
  BasicBlock *IfTrue, *IfFalse;
  auto *Term = Header->getTerminator();
  if (match(Term, m_Br(m_ICmp(Pred, m_Value(LHS), m_Value(RHS)),
                       m_BasicBlock(IfTrue), m_BasicBlock(IfFalse))))
  {
    ConstantInt *LHSI = dyn_cast<ConstantInt>(getValueOnFirstIteration(LHS, FirstIterValue, SQ));
    ConstantInt *RHSI = dyn_cast<ConstantInt>(RHS);
    if (LHS && RHS)
    {
      int64_t l = LHSI->getSExtValue(), r = RHSI->getSExtValue();
      int64_t niter = r - l;
      if (niter > 7)
      {
        niter = rand() % 8;
        static_cast<ICmpInst *>(Term->getOperand(0))->setOperand(1, ConstantInt::get(RHSI->getType(), niter + l, true));
        outs() << r - l - niter << "\n";
      }
      errs() << *Header;
      return niter;
    }
  }
  return -1;
}

static LoopDeletionResult doBreakLoop(Loop *L, DominatorTree &DT, ScalarEvolution &SE,
                                      LoopInfo &LI, MemorySSA *MSSA, int numIter)
{
  if (numIter != 0 && numIter != 1)
    return LoopDeletionResult::Unmodified;

  auto *Latch = L->getLoopLatch();
  assert(Latch && "multiple latches not yet supported");
  auto *Header = L->getHeader();
  SmallVector<BasicBlock *, 4> ExitBlocks;
  L->getExitBlocks(ExitBlocks);
  Loop *OutermostLoop = L;
  while (Loop *Parent = OutermostLoop->getParentLoop())
    OutermostLoop = Parent;

  SE.forgetLoop(L);

  std::unique_ptr<MemorySSAUpdater> MSSAU;
  if (MSSA)
    MSSAU = std::make_unique<MemorySSAUpdater>(MSSA);

  assert(Latch->getTerminator()->getNumSuccessors() == 1 &&
         "Can only handle the case that has a single succ!");

  // Before break loop
  outs() << *Latch;
  if (numIter == 0)
    outs() << *Header;

  auto *BackedgeBB = SplitBlock(Latch, Latch->getTerminator(), &DT, &LI, MSSAU.get());
  DomTreeUpdater DTU(&DT, DomTreeUpdater::UpdateStrategy::Eager);
  (void)changeToUnreachable(BackedgeBB->getTerminator(),
                            /*PreserveLCSSA*/ true, &DTU, MSSAU.get());

  // Erase (and destroy) this loop instance.  Handles relinking sub-loops
  // and blocks within the loop as needed.
  LI.erase(L);

  // If the loop we broke had a parent, then changeToUnreachable might have
  // caused a block to be removed from the parent loop (see loop_nest_lcssa
  // test case in zero-btc.ll for an example), thus changing the parent's
  // exit blocks.  If that happened, we need to rebuild LCSSA on the outermost
  // loop which might have a had a block removed.
  if (OutermostLoop != L)
    formLCSSARecursively(*OutermostLoop, DT, &LI, &SE);

  if (numIter == 1)
    return LoopDeletionResult::Deleted;

  using namespace PatternMatch;
  ICmpInst::Predicate Pred;
  Value *LHS, *RHS;
  BasicBlock *IfTrue, *IfFalse;
  auto *Term = Header->getTerminator();
  if (match(Term, m_Br(m_ICmp(Pred, m_Value(LHS), m_Value(RHS)),
                       m_BasicBlock(IfTrue), m_BasicBlock(IfFalse))))
  {
    BasicBlock *Target, *FalseTarget;
    for (auto *ExitBlk : ExitBlocks)
    {
      if (ExitBlk == IfTrue)
      {
        Target = IfTrue;
        FalseTarget = IfFalse;
        break;
      }
      else if (ExitBlk == IfFalse)
      {
        Target = IfFalse;
        FalseTarget = IfTrue;
        break;
      }
    }
    Header->getTerminator()->eraseFromParent();
    Header->back().eraseFromParent();
    BranchInst::Create(Target, FalseTarget, ConstantInt::getTrue(Header->getContext()), Header);
    outs() << (Target == IfTrue) << "\n";
  }
  return LoopDeletionResult::Deleted;
}

/// If we can prove the backedge is untaken, remove it.  This destroys the
/// loop, but leaves the (now trivially loop invariant) control flow and
/// side effects (if any) in place.
static LoopDeletionResult
breakBackedgeIfNotTaken(Loop *L, DominatorTree &DT, ScalarEvolution &SE,
                        LoopInfo &LI, MemorySSA *MSSA,
                        OptimizationRemarkEmitter &ORE)
{
  assert(L->isLCSSAForm(DT) && "Expected LCSSA!");

  if (!L->getLoopLatch())
    return LoopDeletionResult::Unmodified;

  return doBreakLoop(L, DT, SE, LI, MSSA, numIteration(L, DT, LI));
}

PreservedAnalyses MyLoopDeletionPass::run(Loop &L, LoopAnalysisManager &AM,
                                          LoopStandardAnalysisResults &AR,
                                          LPMUpdater &Updater)
{
  std::string LoopName = std::string(L.getName());
  OptimizationRemarkEmitter ORE(L.getHeader()->getParent());

  // If we can prove the backedge isn't taken, just break it and be done.  This
  // leaves the loop structure in place which means it can handle dispatching
  // to the right exit based on whatever loop invariant structure remains.
  auto Result = breakBackedgeIfNotTaken(&L, AR.DT, AR.SE, AR.LI,
                                        AR.MSSA, ORE);

  if (Result == LoopDeletionResult::Unmodified)
    return PreservedAnalyses::all();

  if (Result == LoopDeletionResult::Deleted)
    Updater.markLoopAsDeleted(L, LoopName);

  auto PA = getLoopPassPreservedAnalyses();
  if (AR.MSSA)
    PA.preserve<MemorySSAAnalysis>();
  return PA;
}

//-----------------------------------------------------------------------------
// New PM Registration
//-----------------------------------------------------------------------------
PassPluginLibraryInfo getLoopDeletionPluginInfo()
{
  return {LLVM_PLUGIN_API_VERSION, PluginName, LLVM_VERSION_STRING,
          [](PassBuilder &PB)
          {
            PB.registerPipelineParsingCallback(
                [&](StringRef Name, LoopPassManager &LPM,
                    ArrayRef<PassBuilder::PipelineElement>)
                {
                  if (Name.equals(PassArg))
                  {
                    LPM.addPass(MyLoopDeletionPass());
                    return true;
                  }

                  return false;
                });
          }};
}

extern "C" LLVM_ATTRIBUTE_WEAK ::llvm::PassPluginLibraryInfo
llvmGetPassPluginInfo()
{
  srand(43);
  return getLoopDeletionPluginInfo();
}
