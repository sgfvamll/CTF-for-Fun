cmake .
make 
clang -Xclang -disable-O0-optnone -S -emit-llvm main.c -o main.mem.ll
clang -Xclang -disable-O0-optnone -S -emit-llvm lib.c -o lib.ll
opt -S -mem2reg main.mem.ll -o main.reg.ll
opt -S --load-pass-plugin ./libLLVMMyOpt.so   --passes="myloop-deletion" main.reg.ll -o main.done.ll > log
clang -O0 main.done.ll lib.ll -o main
strip main
